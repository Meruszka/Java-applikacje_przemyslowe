package pl.smerski.app.zad3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Zad3Application {

	public static void main(String[] args) {
		SpringApplication.run(Zad3Application.class, args);
	}

}
