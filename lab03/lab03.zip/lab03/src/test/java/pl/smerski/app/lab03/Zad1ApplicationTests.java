package pl.smerski.app.lab03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Zad1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
